#include <DHT.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <math.h>

#define DHTPIN 2
#define DHTTYPE DHT22

#define BUZZERPIN 13

#define JOY_X A0
#define JOY_Y A1
#define JOY_BTN 3

#define POT_BPM A2
#define POT_CO2 A3

#define IMPACT_PIN 4

DHT dht(DHTPIN, DHTTYPE);

LiquidCrystal_I2C lcd(0x27, 16, 2);

const float PASSO_METROS = 5.0;

int x = 0;
int y = 0;

int origemX = 0;
int origemY = 0;

int impactos = 0;
bool impactoDetectado = false;

unsigned long ultimoMovimento = 0;
const int intervaloMovimento = 250;

void setup() {

  Serial.begin(9600);

  dht.begin();

  pinMode(BUZZERPIN, OUTPUT);
  pinMode(JOY_BTN, INPUT_PULLUP);
  pinMode(IMPACT_PIN, INPUT_PULLUP);

  lcd.init();
  lcd.backlight();

  lcd.setCursor(0, 0);
  lcd.print("Sistema Start");

  delay(2000);
  lcd.clear();
}

void lerJoystick() {

  int eixoX = analogRead(JOY_X);
  int eixoY = analogRead(JOY_Y);

  if (millis() - ultimoMovimento > intervaloMovimento) {

    if (eixoX > 800) {
      x++;
      ultimoMovimento = millis();
    }

    if (eixoX < 200) {
      x--;
      ultimoMovimento = millis();
    }

    if (eixoY > 800) {
      y++;
      ultimoMovimento = millis();
    }

    if (eixoY < 200) {
      y--;
      ultimoMovimento = millis();
    }
  }

  if (digitalRead(JOY_BTN) == LOW) {

    origemX = x;
    origemY = y;

    Serial.println("Nova origem definida!");

    delay(300);
  }
}

void loop() {

  // Temperatura
  float temperatura = dht.readTemperature();

  if (isnan(temperatura)) {

    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Erro DHT22");

    delay(2000);
    return;
  }

  // BPM
  int valorPotBPM = analogRead(POT_BPM);

  int bpm = map(
    valorPotBPM,
    0,
    1023,
    40,
    180
  );

  // CO2
  int valorPotCO2 = analogRead(POT_CO2);

  int co2 = map(
    valorPotCO2,
    0,
    1023,
    400,
    2000
  );

  // Joystick
  lerJoystick();

  // Distância
  float distancia = sqrt(
    pow((x - origemX) * PASSO_METROS, 2) +
    pow((y - origemY) * PASSO_METROS, 2)
  );

  // Impacto
  if (digitalRead(IMPACT_PIN) == LOW) {

    impactos++;
    impactoDetectado = true;

    Serial.println("IMPACTO DETECTADO!");

    delay(300);

  } else {

    impactoDetectado = false;
  }

  // Serial Monitor
  Serial.println("===== MONITORAMENTO =====");

  Serial.print("Temperatura: ");
  Serial.print(temperatura, 1);
  Serial.println(" C");

  Serial.print("CO2: ");
  Serial.print(co2);
  Serial.println(" ppm");

  Serial.print("Distancia: ");
  Serial.print(distancia, 1);
  Serial.println(" m");

  Serial.print("BPM: ");
  Serial.println(bpm);

  Serial.print("Impactos: ");
  Serial.println(impactos);

  Serial.println("=========================");

  // LCD
  lcd.clear();

  lcd.setCursor(0, 0);

  lcd.print("T:");
  lcd.print((int)temperatura);

  lcd.print(" CO2:");
  lcd.print(co2);

  lcd.setCursor(0, 1);

  lcd.print("D:");

  if ((int)distancia < 10)
    lcd.print("0");

  lcd.print((int)distancia);

  lcd.print(" B:");
  lcd.print(bpm);

  lcd.print(" I:");

  if (impactos < 10)
    lcd.print("0");

  lcd.print(impactos);

  // Alertas
  bool alerta = false;

  if (temperatura > 37.5) alerta = true;
  if (temperatura < 35.0) alerta = true;

  if (distancia >= 100.0) alerta = true;

  if (bpm > 120) alerta = true;
  if (bpm < 50) alerta = true;

  if (co2 > 1000) alerta = true;

  if (impactoDetectado) alerta = true;

  // Buzzer
  if (alerta) {
    tone(BUZZERPIN, 1000);
  } else {
    noTone(BUZZERPIN);
  }

  delay(2000);
}